package br.edu.cesarschool.cc.poo.ac.cliente;

public class ProgramaCadastroCliente {

    public static void main(String[] args) {
        TelaCliente telaCliente = new TelaCliente();
        telaCliente.inicializaTelaCliente();
    }
}